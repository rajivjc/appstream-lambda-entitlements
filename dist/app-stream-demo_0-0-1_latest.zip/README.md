# app-stream-entitlements
Entitlement service for AWS Appstream.
